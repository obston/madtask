// src/app/conversaciones/[session_id]/page.tsx
import clsx from "clsx";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import ConversationSidebarShell from "@/components/ConversationSidebarShell";
import ChatComposer from "@/components/ChatComposer";
import { getBaseUrl } from "@/lib/getBaseUrl";

type Msg = { role: string; message: string | null; created_at: string };

export default async function ConversacionPage({
  params,
}: { params: { session_id: string } }) {
  const base = await getBaseUrl();

  const r = await fetch(
    `${base}/api/conversaciones/${encodeURIComponent(params.session_id)}`,
    { cache: "no-store" }
  );
  const j = r.ok ? await r.json() : { rows: [] };
  const rows = (j.rows ?? []) as Msg[];

  // agrupar por día para separadores
  const groups = rows.reduce((acc: Record<string, Msg[]>, m) => {
    const key = m.created_at?.slice(0, 10) ?? "desconocido";
    (acc[key] ||= []).push(m);
    return acc;
  }, {});
  const orderedDates = Object.keys(groups).sort(); // ya vienen ASC, igual aseguramos

  return (
    // altura fija de la zona de trabajo; ajusta 96px si tu topbar es más/menos alta
    <div className="h-[calc(100vh-96px)] min-h-0 grid grid-cols-[320px,1fr] gap-4">

      {/* IZQUIERDA: LISTA (scroll propio) */}
      <div className="min-h-0 rounded-2xl border border-neutral-800/70 bg-neutral-900/40 flex flex-col">
        <div className="px-4 py-3 border-b border-neutral-800/70">
          <h3 className="text-sm font-semibold text-neutral-200">Conversaciones</h3>
        </div>
        {/* solo este div scrollea */}
        <div className="flex-1 min-h-0 overflow-y-auto">
          <ConversationSidebarShell active={params.session_id} />
        </div>
      </div>

      {/* DERECHA: CHAT (scroll propio) */}
      <div className="min-h-0 rounded-2xl border border-neutral-800/70 bg-neutral-900/40 flex flex-col">
        {/* header */}
        <div className="px-4 py-3 border-b border-neutral-800/70">
          <h3 className="text-sm font-semibold text-neutral-200">
            Conversación {params.session_id}
          </h3>
        </div>

        {/* timeline: SOLO esto scrollea */}
        <div className="flex-1 min-h-0 overflow-y-auto px-4 py-3">
          {orderedDates.map((date) => (
            <div key={date} className="mb-6">
              {/* separador de fecha */}
              <div className="flex items-center gap-3 my-2">
                <div className="h-px flex-1 bg-neutral-800" />
                <div className="text-xs text-neutral-400">
                  {format(new Date(date), "d MMM yyyy", { locale: es })}
                </div>
                <div className="h-px flex-1 bg-neutral-800" />
              </div>

              {/* burbujas del día */}
              <div className="space-y-2">
                {groups[date].map((m, i) => {
                  if (m.role === "system") return null;

                  const isCustomer = m.role === "user";        // cliente final → izquierda
                  const isBotOrAgent = !isCustomer;            // bot / agente → derecha

                  return (
                    <div
                      key={`${date}-${i}`}
                      className={clsx(
                        "max-w-[85%] md:max-w-[70%] rounded-2xl border px-3 py-2",
                        isCustomer
                          ? "self-start bg-neutral-900/70 border-neutral-800/70"       // izq
                          : "self-end bg-neutral-800/50 border-neutral-700/60 ml-auto" // der
                      )}
                    >
                      <div className="text-xs text-neutral-400 mb-1">
                        {isCustomer ? "cliente" : "bot"} ·{" "}
                        {m.created_at ? format(new Date(m.created_at), "HH:mm") : "--:--"}
                      </div>
                      <div className="text-neutral-100 whitespace-pre-wrap">
                        {m.message || "—"}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          {rows.length === 0 && (
            <div className="text-sm text-neutral-400">
              No hay mensajes en esta conversación.
            </div>
          )}
        </div>

        {/* composer: FIJO (no scrollea) */}
        <div className="shrink-0 border-t border-neutral-800/70">
          <div className="px-4 py-2 text-xs text-neutral-400">
            Escribe para tomar control. Si dejas de escribir, el bot retomará.
          </div>
          <div className="p-3">
            <ChatComposer sessionId={params.session_id} />
          </div>
        </div>
      </div>
    </div>
  );
}
