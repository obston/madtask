"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import clsx from "clsx";
import { shortWhen } from "@/lib/date";

type Row = {
  session_id: string;
  last_at: string;                // ISO
  last_message: string | null;
  last_role: "user" | "assistant" | "system" | null;
  telefono_usuario: string | null;
  last_user_message: string | null;
};

export default function ConversationSidebarClient({
  rows,
  active,
}: { rows: Row[]; active?: string }) {
  const [q, setQ] = useState("");

  const list = rows ?? [];  // <-- fallback seguro
  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return list;
    return list.filter((r) => {
      const haystack = [
        r.session_id,
        r.telefono_usuario ?? "",
        r.last_message ?? "",
        r.last_user_message ?? "",
      ]
        .join(" ")
        .toLowerCase();
      return haystack.includes(needle);
    });
}, [list, q]);

  return (
    <div className="flex h-full flex-col">
      {/* buscador STICKY */}
      <div className="sticky top-0 z-10 bg-neutral-900/90 backdrop-blur p-3 border-b border-neutral-800/70">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar conversación por número, usuario o mensaje…"
          className="w-full rounded-lg bg-neutral-900/60 border border-neutral-800 px-3 py-2 text-sm outline-none focus:border-neutral-700"
        />
      </div>

      {/* lista scrolleable (el contenedor padre del sidebar ya tiene overflow) */}
      <ul className="divide-y divide-neutral-800/70">
        {filtered.length === 0 && (
          <li className="p-4 text-sm text-neutral-400">Sin resultados.</li>
        )}

        {filtered.map((r) => {
          const title = r.telefono_usuario || r.session_id;
          const preview = (r.last_user_message || r.last_message || "—")
            .replace(/\s+/g, " ")
            .trim();
          const when = shortWhen(new Date(r.last_at)); // “hoy 19:42”, “ayer”, “17/09/25”
          const isActive = active === r.session_id;
          const lastFromCustomer = r.last_role === "user";

          return (
            <li key={r.session_id}>
              <Link
                href={`/conversaciones/${encodeURIComponent(r.session_id)}`}
                className={clsx(
                  "block px-3 py-3 hover:bg-neutral-900/70",
                  isActive && "bg-neutral-900/70"
                )}
              >
                {/* fila superior: título a la izq, fecha a la der */}
                <div className="flex items-center gap-2">
                  <span className="truncate font-medium text-neutral-100">
                    {title}
                  </span>
                  {lastFromCustomer && (
                    <span className="inline-flex items-center rounded-full border border-neutral-700 px-2 py-0.5 text-[10px] text-neutral-300">
                      cliente
                    </span>
                  )}
                  <span className="ml-auto shrink-0 text-xs text-neutral-400">
                    {when}
                  </span>
                </div>
                {/* preview */}
                <div className="mt-0.5 truncate text-sm text-neutral-400">
                  {preview}
                </div>
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
