// src/components/ConversationSidebarShell.tsx
import { q } from "@/lib/db";
import { resolveClienteId } from "@/lib/tenant";
import ConversationSidebarClient from "@/components/ConversationSidebarClient";

type Row = {
  session_id: string;
  last_at: string;
  last_message: string | null;
  last_role: "user" | "assistant" | "system" | null;
  telefono_usuario: string | null;
  last_user_message: string | null; // para preview preferente
};

export default async function ConversationSidebarShell({ active }: { active?: string }) {
  const clienteId = await resolveClienteId();

   const rows = await q<Row>`
    WITH last_any AS (
      SELECT DISTINCT ON (session_id)
             session_id,
             created_at    AS last_at,
             message       AS last_message,
             role          AS last_role,
             telefono_usuario
      FROM public.n8n_chat_histories
      WHERE cliente_id = ${clienteId}
      ORDER BY session_id, created_at DESC
    ),
    last_user AS (
      SELECT DISTINCT ON (session_id)
             session_id,
             message AS last_user_message
      FROM public.n8n_chat_histories
      WHERE cliente_id = ${clienteId} AND role = 'user'
      ORDER BY session_id, created_at DESC
    )
    SELECT a.session_id,
           a.last_at::text,
           a.last_message,
           a.last_role::text,
           a.telefono_usuario,
           u.last_user_message
    FROM last_any a
    LEFT JOIN last_user u USING (session_id)
    ORDER BY a.last_at DESC
    LIMIT 200
  `;
  return <ConversationSidebarClient active={active} rows={rows} />;
}
