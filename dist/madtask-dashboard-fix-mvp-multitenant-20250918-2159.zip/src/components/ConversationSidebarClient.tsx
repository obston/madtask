// src/components/ConversationSidebarClient.tsx
"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import clsx from "clsx";
import { shortWhen } from "@/lib/date";

type Row = {
  session_id: string;
  last_at: string;
  last_message: string | null;
  last_role: "user" | "assistant" | "system" | null;
  telefono_usuario: string | null;
  last_user_message: string | null;
};

export default function ConversationSidebarClient({
  active,
  initialRows,
}: {
  active?: string;
  initialRows: Row[];
}) {
  const [q, setQ] = useState("");

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return initialRows;
    return initialRows.filter((r) => {
      const title = (r.telefono_usuario || r.session_id).toLowerCase();
      const snippet =
        (r.last_user_message || r.last_message || "—").toLowerCase();
      return title.includes(term) || snippet.includes(term);
    });
  }, [q, initialRows]);

  return (
        <div className="flex h-full flex-col">
          {/* buscador STICKY dentro del sidebar */}
          <div className="p-2 border-b border-neutral-800/70 sticky top-0 z-10
                          bg-neutral-900/90 backdrop-blur">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar conversación…"
          className="w-full rounded-lg bg-neutral-900/60 border border-neutral-800 px-3 py-2 text-sm outline-none focus:border-neutral-700"
        />
      </div>

      {/* lista */}
      <div className="overflow-y-auto">
        {rows.length === 0 ? (
          <div className="p-4 text-sm text-neutral-400">Sin resultados.</div>
        ) : (
          <ul className="divide-y divide-neutral-800/70">
            {rows.map((r) => {
              const when = shortWhen(new Date(r.last_at));
              const title = r.telefono_usuario || r.session_id;
              // preview: preferimos último mensaje de usuario
              const preview = (r.last_user_message || r.last_message || "—")
                .replace(/\s+/g, " ")
                .trim();
                const isActive = active === r.session_id;
                const lastFromCustomer = r.last_role === "user";

              return (
                <li key={r.session_id}>
                  <Link
                    href={`/conversaciones/${encodeURIComponent(r.session_id)}`}
                    className={clsx(
                     "block px-3 py-3 hover:bg-neutral-900/70",
                      isActive && "bg-neutral-900/70"
                    )}
                  >
                    {/* Cabecera del item: título + fecha a la derecha */}
                    <div className="flex items-center gap-2">
                      <span className="truncate font-medium text-neutral-100">
                        {title}
                      </span>
                      {lastFromCustomer && (
                        <span className="inline-flex items-center rounded-full border border-neutral-700 px-2 py-0.5 text-[10px] text-neutral-300">
                          cliente
                        </span>
                      )}
                      <span className="ml-auto shrink-0 text-xs text-neutral-400">
                        {when}
                      </span>
                    </div>
                    {/* preview de mensaje */}
                    <div className="mt-0.5 truncate text-sm text-neutral-400">
                      {preview}
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
