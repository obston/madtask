// src/app/conversaciones/[session_id]/page.tsx
import ConversationSidebarShell from "@/components/ConversationSidebarShell";
import ChatComposer from "@/components/ChatComposer";
import { getBaseUrl } from "@/lib/getBaseUrl";
import clsx from "clsx";
import { format } from "date-fns";
import { es } from "date-fns/locale";

export default async function ConversacionPage({
  params,
}: { params: { session_id: string } }) {
  const base = await getBaseUrl();
  const r = await fetch(
    `${base}/api/conversaciones/${encodeURIComponent(params.session_id)}`,
    { cache: "no-store" }
  );
  const j = r.ok ? await r.json() : { rows: [] };
  const rows = (j.rows ?? []) as Array<{
    role: "user" | "assistant" | "system" | "agent";
    message: string | null;
    created_at: string;
  }>;

  // Agrupa por día (YYYY-MM-DD) para separadores de fecha
  const groups = rows.reduce((acc: Record<string, typeof rows>, m) => {
    const key = m.created_at?.slice(0, 10) ?? "desconocido";
    (acc[key] ||= []).push(m);
    return acc;
  }, {});
  const orderedDates = Object.keys(groups).sort(); // la query ya viene ASC

  return (
        <div
          className="grid grid-cols-1 md:grid-cols-[320px,1fr] gap-4 min-h-0"
          style={{ height: "calc(100vh - 96px)" }} // ajusta si tu topbar cambia
        >
      {/* Columna izquierda: sidebar (con su propio scroll) */}
      <div className="rounded-2xl border border-neutral-800/70 bg-neutral-900/40 flex flex-col min-h-0">
       {/* header fijo */}
       <div className="p-4 border-b border-neutral-800/70 shrink-0">
          <h3 className="text-sm font-semibold text-neutral-200">Conversaciones</h3>
        </div>
        {/* lista scrolleable */}
       <div className="flex-1 overflow-y-auto min-h-0">
          <ConversationSidebarShell active={params.session_id} />
        </div>
      </div>

      {/* Columna derecha: chat (área de mensajes scrollea, composer fijo) */}
     {/* lista scrolleable */}
       <div className="flex-1 overflow-y-auto min-h-0">
        {/* Header */}
        <div className="px-4 py-3 border-b border-neutral-800/70">
          <h3 className="text-sm font-semibold text-neutral-200">
            Conversación {params.session_id}
          </h3>
        </div>

        {/* Mensajes (solo este panel scrollea) */}
        <div className="flex-1 overflow-y-auto px-4 py-3 min-h-0">
          {orderedDates.length > 0 ? (
            orderedDates.map((date) => (
              <div key={date} className="mb-6">
                {/* Separador de fecha */}
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-px flex-1 bg-neutral-800" />
                  <div className="text-xs text-neutral-400">
                    {format(new Date(date), "d MMM yyyy", { locale: es })}
                  </div>
                  <div className="h-px flex-1 bg-neutral-800" />
                </div>

                {/* Burbujas del día */}
                <div className="flex flex-col gap-2">
                  {groups[date].map((m, i) => {
                    if (m.role === "system") return null; // ocultamos system
                    const isCustomer = m.role === "user"; // cliente final
                    const isBot = m.role === "assistant";
                    const who = isCustomer ? "cliente" : (isBot ? "bot" : "agente");

                    return (
                      <div
                        key={`${date}-${i}`}
                        className={clsx(
                          "max-w-[85%] md:max-w-[70%] rounded-2xl border px-3 py-2",
                          isCustomer
                            ? "self-start bg-neutral-900/70 border-neutral-800/70"   // izquierda = cliente
                            : "self-end bg-neutral-800/50 border-neutral-700/60 ml-auto" // derecha = bot/agente
                        )}
                      >
                        <div className="text-xs text-neutral-400 mb-1">
                          {who} · {m.created_at ? format(new Date(m.created_at), "HH:mm") : "--:--"}
                        </div>
                        <div className="text-neutral-100 whitespace-pre-wrap">
                          {m.message || "—"}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          ) : (
            <div className="text-sm text-neutral-400">No hay mensajes en esta conversación.</div>
          )}
        </div>

        {/* Composer (no scrollea) */}
        <div className="shrink-0">
+         <ChatComposer sessionId={params.session_id} />
+       </div>
      </div>
    </div>
  );
}
