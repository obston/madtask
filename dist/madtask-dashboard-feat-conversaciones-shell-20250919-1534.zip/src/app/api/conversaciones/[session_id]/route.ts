// src/app/api/conversaciones/[session_id]/route.ts
import { NextRequest } from "next/server";
import { q } from "@/lib/db";

type Params = { session_id: string };

// GET /api/conversaciones/[session_id]?cursor_before=ISO&limit=40
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<Params> }
) {
  const { session_id } = await params;
  const { searchParams } = new URL(req.url);
  const limit = Math.min(Number(searchParams.get("limit") || 40), 100);
  const cursorBefore = searchParams.get("cursor_before"); // ISO: trae mensajes MÁS antiguos que esto

  const rows = await q<{
        id: number;
        role: "user" | "assistant" | "system" | "agent";
        message: string;
        created_at: string;
        telefono_usuario: string | null;
        api_key_publica: string | null;
        cliente_id: number | null;
      }>`
        SELECT id, role, message, created_at, telefono_usuario, api_key_publica, cliente_id
        FROM public.n8n_chat_histories
        WHERE session_id = ${session_id}
          ${cursorBefore ? q`AND created_at < ${new Date(cursorBefore).toISOString()}` : q``}
        ORDER BY created_at DESC
        LIMIT ${limit + 1}
      `;
    

  const hasMore = rows.length > limit;
  const slice = rows.slice(0, limit);
  const nextCursorBefore = hasMore ? slice[slice.length - 1]?.created_at : null;

  // El frontend mostrará ASC, así que invertimos aquí si lo prefieres:
  const itemsAsc = [...slice].reverse();

  return Response.json({
    items: itemsAsc,
    nextCursorBefore,
  });
}

// POST /api/conversaciones/[session_id]/reply
// body: { message: string }
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<Params> }
) {
  const { session_id } = await params;
  const body = await req.json().catch(() => ({}));
  const text: string = (body?.message || "").toString().trim();
  if (!text) {
    return new Response(JSON.stringify({ error: "Mensaje vacío" }), { status: 400 });
  }

  // Tomar api_key_publica / cliente_id / telefono_usuario desde la última fila de la sesión
  const meta = await q<{
        api_key_publica: string;
        cliente_id: number | null;
        telefono_usuario: string | null;
      }>`
        SELECT api_key_publica, cliente_id, telefono_usuario
        FROM public.n8n_chat_histories
        WHERE session_id = ${session_id}
        ORDER BY id DESC
        LIMIT 1
      `;
  const last = meta[0];
  if (!last?.api_key_publica) {
    return new Response(JSON.stringify({ error: "Sesión desconocida" }), { status: 404 });
  }

  // Insertar turno del agente (assistant)
  const inserted = await q<{
    id: number; role: string; message: string; created_at: string;
  }>`
    INSERT INTO public.n8n_chat_histories
      (session_id, api_key_publica, cliente_id, role, message, telefono_usuario)
    VALUES (
      ${session_id},
      ${last.api_key_publica},
      ${last.cliente_id},
      'assistant',
      ${text},
      ${last.telefono_usuario}
    )
    RETURNING id, role, message, created_at
  `;

  return Response.json({ item: inserted[0] }, { status: 201 });
}
