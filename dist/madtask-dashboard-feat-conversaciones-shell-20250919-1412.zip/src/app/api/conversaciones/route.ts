// src/app/api/conversaciones/route.ts
import { NextRequest } from "next/server";
import { q } from "@/lib/db"; // tu helper de Postgres con Pool

// Devuelve la última fila por session_id (último mensaje), con cursor por created_at
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const qtext = (searchParams.get("q") || "").trim();
  const limit = Math.min(Number(searchParams.get("limit") || 20), 50);
  const cursor = searchParams.get("cursor"); // ISO string de created_at (último last_at de la página previa)

  const args: any[] = [];
  let where = "1=1";
  if (qtext) {
    args.push(`%${qtext}%`);
    where += ` AND (session_id ILIKE $${args.length} OR message ILIKE $${args.length})`;
  }
  if (cursor) {
    args.push(new Date(cursor).toISOString());
    where += ` AND created_at < $${args.length}`;
  }

  // DISTINCT ON para obtener la última fila de cada sesión
  const sql = `
    SELECT DISTINCT ON (session_id)
      session_id,
      api_key_publica,
      cliente_id,
      telefono_usuario,
      role,
      message AS last_message,
      created_at AS last_at
    FROM public.n8n_chat_histories
    WHERE ${where}
    ORDER BY session_id, created_at DESC
    LIMIT $${args.length + 1};
  `;
  args.push(limit + 1);
  const rows = await q(sql, args);

  const hasMore = rows.length > limit;
  const items = rows.slice(0, limit);
  const nextCursor = hasMore ? items[items.length - 1]?.last_at : null;

  // (opcional) contadores rápidos para KPIs
  const counts = await q<{ total: number }>(`
    SELECT COUNT(DISTINCT session_id)::int AS total
    FROM public.n8n_chat_histories
    WHERE ${where.replace("created_at <", "created_at <")} -- misma condición sin tocar
  `, args.slice(0, -1));

  return Response.json({
    items,
    nextCursor,
    totalSessions: counts?.[0]?.total ?? null,
  });
}
